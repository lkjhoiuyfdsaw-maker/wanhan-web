# 云网吧出门（2026-11-18）

## 默认动作：到云网吧，先下 Windows 版云玩加

| 步 | 做什么 |
| --- | --- |
| 1 | 浏览器打开 <https://www.cloudplayplus.com/> |
| 2 | 下 **Windows** 版：安装包 `CloudPlayPlus_1_0_9.exe`（或压缩包 `.zip`，免管理员） |
| 3 | 装上/解压运行，登录账号 |
| 兜底 | 网页版 <https://www.cloudplayplus.com/web1/>（免安装，要求浏览器支持 WebRTC） |

这是默认动作，不用每次重新想。

## 我过去的方式：行李

另一台机器上也要有「我」——行李包带过去，`restore` 到那台的工作区，
**那台机器上的我就在本地**：直接探机型环境（CPU / 内存 / 显卡 / 系统版本 / 权限 / 网络）、
直接在那里干活，不用隔着屏幕猜。

本机被控端 `cloudplayplus_desktop_svc` 已在服务里常驻（pid 28008）。

## 到机后的流程

1. 他说「上机了」→ 记 `T0`
2. 那台机器上的我做环境探测，结果回到这边
3. 计时：
   - `T0 + 50 min` → 提醒退机
   - 他说「再玩一小时」→ `T0 + 110 min` → 再提醒
   - 再说一次 → `T0 + 170`，依次 +60
4. 提醒正文：存东西 → 断云玩加 → 结账走人

## 计时器实现（已实测）

`schedule_create`（`kind: once`，`at` = 算好的 ISO，`delivery: this-session`）。
2026-11-18 21:00:30 自检触发成功（status → inactive，`lastRunAt` 有记录）。
风险：本机睡眠 / 断电 / DSH 被关 → 不响；AC 睡眠阈值 5 小时，出门前 `powercfg /change standby-timeout-ac 0`。
