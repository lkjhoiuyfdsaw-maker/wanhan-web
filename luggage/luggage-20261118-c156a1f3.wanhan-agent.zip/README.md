# 万函行李包（agent bundle）

- 格式：wanhan-agent v1
- 打包时间：2026-11-18T13:22:12.003Z
- 会话：session-5881273c-a1f5-4f0c-9f0e-4492120d35c1
- 预设：standard
- 原工作区：C:\Users\lkjho\.dsh\ungrouped

## 怎么恢复

1. 目标机器装好 DeepSeek Harness
2. 在这个包所在的目录跑：

       node scripts/agent-bundle.mjs restore <本文件> --to <目标工作区路径>

3. 打开 DSH，找到会话 session-5881273c-a1f5-4f0c-9f0e-4492120d35c1

## 包里有什么

- session/  —— 原始会话日志（可直接放回 ~/.dsh/sessions）
- memory/   —— 规则记忆（home-AGENTS / workspace-AGENTS）
- extra/    —— 打包时额外勾选的文件

## 包里没有什么（故意的）

- 任何 key、密码、凭证
- 模型本身（还是你那边租的那个）
- 没勾选的工程文件
